import 'package:flutter/material.dart';
import '../providers/vpn_provider.dart';
import '../theme/app_theme.dart';

class StatusBadge extends StatefulWidget {
  final VpnState state;
  final String? errorMessage;

  const StatusBadge({
    super.key,
    required this.state,
    this.errorMessage,
  });

  @override
  State<StatusBadge> createState() => _StatusBadgeState();
}

class _StatusBadgeState extends State<StatusBadge> with SingleTickerProviderStateMixin {
  late AnimationController _dotController;

  @override
  void initState() {
    super.initState();
    _dotController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _dotController.dispose();
    super.dispose();
  }

  Color get _statusColor {
    switch (widget.state) {
      case VpnState.connected:
        return AppTheme.connectedGreen;
      case VpnState.connecting:
      case VpnState.disconnecting:
        return AppTheme.connectingYellow;
      case VpnState.error:
        return AppTheme.disconnectedRed;
      case VpnState.disconnected:
      default:
        return AppTheme.textMuted;
    }
  }

  String get _statusLabel {
    switch (widget.state) {
      case VpnState.connected:
        return "CONNECTED & SECURED";
      case VpnState.connecting:
        return "ESTABLISHING TUNNEL...";
      case VpnState.disconnecting:
        return "DISCONNECTING...";
      case VpnState.error:
        return widget.errorMessage ?? "CONNECTION FAILED";
      case VpnState.disconnected:
      default:
        return "NOT CONNECTED";
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _dotController,
      builder: (context, child) {
        final opacity = (widget.state == VpnState.connecting || widget.state == VpnState.connected)
            ? 0.4 + (_dotController.value * 0.6)
            : 1.0;

        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          decoration: BoxDecoration(
            color: _statusColor.withOpacity(0.12),
            borderRadius: BorderRadius.circular(30),
            border: Border.all(
              color: _statusColor.withOpacity(0.35),
              width: 1,
            ),
            boxShadow: widget.state == VpnState.connected
                ? [
                    BoxShadow(
                      color: _statusColor.withOpacity(0.2),
                      blurRadius: 10,
                      spreadRadius: 1,
                    )
                  ]
                : [],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Opacity(
                opacity: opacity,
                child: Container(
                  width: 10,
                  height: 10,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _statusColor,
                    boxShadow: [
                      BoxShadow(
                        color: _statusColor.withOpacity(0.8),
                        blurRadius: 6,
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Flexible(
                child: Text(
                  _statusLabel,
                  style: TextStyle(
                    color: _statusColor,
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 0.8,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

# Muneeb VPN APK Build Automation Script
# Usage: Execute this script in PowerShell to compile the Release APK

Write-Host "=========================================" -ForegroundColor Cyan
Write-Host " Building Muneeb VPN Release APK Package " -ForegroundColor Purple
Write-Host " App by Muneeb                           " -ForegroundColor Cyan
Write-Host "=========================================" -ForegroundColor Cyan

# 1. Ensure Flutter is accessible
if (-not (Get-Command "flutter" -ErrorAction SilentlyContinue)) {
    Write-Host "Error: Flutter SDK not found in PATH." -ForegroundColor Red
    Write-Host "Please install Flutter or add Flutter bin path (e.g. C:\flutter\bin) to PATH." -ForegroundColor Yellow
    Exit 1
}

# 2. Get dependencies
Write-Host "`n[1/3] Fetching Flutter dependencies..." -ForegroundColor Green
flutter pub get

# 3. Clean past builds
Write-Host "`n[2/3] Cleaning build workspace..." -ForegroundColor Green
flutter clean
flutter pub get

# 4. Build Release APK
Write-Host "`n[3/3] Compiling Release APK..." -ForegroundColor Green
flutter build apk --release --split-per-abi

if ($LASTEXITCODE -eq 0) {
    Write-Host "`n=========================================" -ForegroundColor Green
    Write-Host " SUCCESS: Release APK Built Successfully! " -ForegroundColor Green
    Write-Host " APK Path: build/app/outputs/flutter-apk/app-release.apk" -ForegroundColor Yellow
    Write-Host "=========================================" -ForegroundColor Green
} else {
    Write-Host "`nBuild Failed. Check log output above." -ForegroundColor Red
}

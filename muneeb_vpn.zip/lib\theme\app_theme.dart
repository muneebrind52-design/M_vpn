import 'package:flutter/material.dart';

class AppTheme {
  // Brand Neon Colors
  static const Color primaryNeon = Color(0xFF00D4FF); // Neon Blue / Cyan
  static const Color secondaryNeon = Color(0xFF7B2FBE); // Neon Purple
  static const Color accentCyan = Color(0xFF00F0FF);
  
  // Background & Surface Colors
  static const Color bgDark = Color(0xFF0B0E17);
  static const Color bgSurface = Color(0xFF131A29);
  static const Color cardSurface = Color(0xFF1A2338);
  static const Color cardBorder = Color(0x2600D4FF); // 15% opacity cyan border
  
  // Text Colors
  static const Color textWhite = Color(0xFFFFFFFF);
  static const Color textMuted = Color(0xFF94A3B8);
  static const Color textDim = Color(0xFF64748B);
  
  // Status Colors
  static const Color connectedGreen = Color(0xFF00E676);
  static const Color connectingYellow = Color(0xFFFFB300);
  static const Color disconnectedRed = Color(0xFFFF5252);

  // Gradient definitions
  static const LinearGradient neonGradient = LinearGradient(
    colors: [primaryNeon, secondaryNeon],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient bgGradient = LinearGradient(
    colors: [Color(0xFF080B12), Color(0xFF0F1524), Color(0xFF0B0E17)],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );

  static const LinearGradient cardGradient = LinearGradient(
    colors: [Color(0xFF1C263B), Color(0xFF141B2B)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient connectedGradient = LinearGradient(
    colors: [Color(0xFF00E676), Color(0xFF00B0FF)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  // Glow Shadows
  static List<BoxShadow> neonGlow({Color color = primaryNeon, double opacity = 0.4, double blur = 20.0}) {
    return [
      BoxShadow(
        color: color.withOpacity(opacity),
        blurRadius: blur,
        spreadRadius: 2,
      ),
      BoxShadow(
        color: color.withOpacity(opacity * 0.5),
        blurRadius: blur * 1.5,
        spreadRadius: 4,
      ),
    ];
  }

  static ThemeData get darkTheme {
    return ThemeData.dark().copyWith(
      scaffoldBackgroundColor: bgDark,
      primaryColor: primaryNeon,
      colorScheme: const ColorScheme.dark(
        primary: primaryNeon,
        secondary: secondaryNeon,
        surface: bgSurface,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        titleTextStyle: TextStyle(
          color: textWhite,
          fontSize: 20,
          fontWeight: FontWeight.bold,
          letterSpacing: 0.5,
        ),
      ),
      cardTheme: CardTheme(
        color: cardSurface,
        elevation: 6,
        shadowColor: Colors.black.withOpacity(0.5),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: const BorderSide(color: cardBorder, width: 1),
        ),
      ),
    );
  }

  // Ping status color calculator
  static Color getPingColor(int ping) {
    if (ping < 50) return const Color(0xFF00E676);
    if (ping < 85) return const Color(0xFFFFB300);
    return const Color(0xFFFF5252);
  }
}

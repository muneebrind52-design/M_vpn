import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class SpeedWidget extends StatelessWidget {
  final double downloadSpeed;
  final double uploadSpeed;
  final bool isConnected;

  const SpeedWidget({
    super.key,
    required this.downloadSpeed,
    required this.uploadSpeed,
    required this.isConnected,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
      decoration: BoxDecoration(
        color: AppTheme.cardSurface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: AppTheme.cardBorder,
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          // Download Speed Column
          _SpeedItem(
            label: "DOWNLOAD",
            speed: isConnected ? "${downloadSpeed.toStringAsFixed(1)} MB/s" : "0.0 MB/s",
            icon: Icons.arrow_downward_rounded,
            accentColor: AppTheme.primaryNeon,
          ),
          Container(
            height: 36,
            width: 1,
            color: Colors.white.withOpacity(0.1),
          ),
          // Upload Speed Column
          _SpeedItem(
            label: "UPLOAD",
            speed: isConnected ? "${uploadSpeed.toStringAsFixed(1)} MB/s" : "0.0 MB/s",
            icon: Icons.arrow_upward_rounded,
            accentColor: AppTheme.secondaryNeon,
          ),
        ],
      ),
    );
  }
}

class _SpeedItem extends StatelessWidget {
  final String label;
  final String speed;
  final IconData icon;
  final Color accentColor;

  const _SpeedItem({
    required this.label,
    required this.speed,
    required this.icon,
    required this.accentColor,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: accentColor.withOpacity(0.12),
            shape: BoxShape.circle,
            border: Border.all(
              color: accentColor.withOpacity(0.3),
            ),
          ),
          child: Icon(
            icon,
            color: accentColor,
            size: 18,
          ),
        ),
        const SizedBox(width: 12),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              label,
              style: const TextStyle(
                color: AppTheme.textMuted,
                fontSize: 10,
                fontWeight: FontWeight.w600,
                letterSpacing: 1.0,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              speed,
              style: const TextStyle(
                color: AppTheme.textWhite,
                fontSize: 15,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ],
    );
  }
}

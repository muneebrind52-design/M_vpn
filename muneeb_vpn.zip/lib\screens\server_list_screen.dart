import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/server_model.dart';
import '../providers/vpn_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/server_card.dart';

class ServerListScreen extends StatefulWidget {
  const ServerListScreen({super.key});

  @override
  State<ServerListScreen> createState() => _ServerListScreenState();
}

class _ServerListScreenState extends State<ServerListScreen> {
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';
  bool _isLoading = false;

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _refreshList() async {
    setState(() => _isLoading = true);
    await Future.delayed(const Duration(milliseconds: 600));
    if (mounted) {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final vpnProvider = Provider.of<VpnProvider>(context);

    // Filter server list by search query
    final filteredServers = vpnProvider.servers.where((server) {
      final query = _searchQuery.toLowerCase();
      return server.country.toLowerCase().contains(query) ||
          server.location.toLowerCase().contains(query) ||
          server.ipAddress.contains(query);
    }).toList();

    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        title: const Text("Select Server"),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: AppTheme.primaryNeon),
            onPressed: _refreshList,
            tooltip: "Refresh Pings",
          ),
        ],
      ),
      body: Column(
        children: [
          // Search & Filter Header Bar
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Container(
              decoration: BoxDecoration(
                color: AppTheme.cardSurface,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppTheme.cardBorder),
              ),
              child: TextField(
                controller: _searchController,
                onChanged: (value) => setState(() => _searchQuery = value),
                style: const TextStyle(color: AppTheme.textWhite),
                decoration: InputDecoration(
                  hintText: "Search 12 locations...",
                  hintStyle: const TextStyle(color: AppTheme.textMuted),
                  prefixIcon: const Icon(Icons.search_rounded, color: AppTheme.primaryNeon),
                  suffixIcon: _searchQuery.isNotEmpty
                      ? IconButton(
                          icon: const Icon(Icons.clear_rounded, color: AppTheme.textDim),
                          onPressed: () {
                            _searchController.clear();
                            setState(() => _searchQuery = '');
                          },
                        )
                      : null,
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(vertical: 14),
                ),
              ),
            ),
          ),

          // Auto-Select Optimal Action Bar
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
            child: GestureDetector(
              onTap: () async {
                await vpnProvider.autoSelectOptimalServer();
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text("Auto-selected fastest server: ${vpnProvider.selectedServer.country} (${vpnProvider.selectedServer.pingMs}ms)"),
                      backgroundColor: AppTheme.secondaryNeon,
                      duration: const Duration(seconds: 2),
                    ),
                  );
                }
              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                decoration: BoxDecoration(
                  gradient: AppTheme.neonGradient,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: AppTheme.neonGlow(color: AppTheme.primaryNeon, opacity: 0.25, blur: 10),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [
                    Icon(Icons.flash_on_rounded, color: Colors.white, size: 20),
                    SizedBox(width: 8),
                    Text(
                      "AUTO-SELECT OPTIMAL SERVER",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.0,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          const SizedBox(height: 8),

          // Server Count Label
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
            child: Row(
              children: [
                Text(
                  "LOCATION LIST (${filteredServers.length})",
                  style: const TextStyle(
                    color: AppTheme.textMuted,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.2,
                  ),
                ),
              ],
            ),
          ),

          // Server Cards List View
          Expanded(
            child: _isLoading
                ? const Center(
                    child: CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation<Color>(AppTheme.primaryNeon),
                    ),
                  )
                : filteredServers.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: const [
                            Icon(Icons.search_off_rounded, size: 48, color: AppTheme.textDim),
                            SizedBox(height: 12),
                            Text(
                              "No servers found matching query",
                              style: TextStyle(color: AppTheme.textMuted),
                            ),
                          ],
                        ),
                      )
                    : RefreshIndicator(
                        onRefresh: _refreshList,
                        color: AppTheme.primaryNeon,
                        backgroundColor: AppTheme.cardSurface,
                        child: ListView.builder(
                          padding: const EdgeInsets.only(bottom: 20, top: 4),
                          itemCount: filteredServers.length,
                          itemBuilder: (context, index) {
                            final server = filteredServers[index];
                            final isSelected = vpnProvider.selectedServer.id == server.id;

                            return ServerCard(
                              server: server,
                              isSelected: isSelected,
                              onTap: () {
                                vpnProvider.selectServer(server);
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text("Selected ${server.country} (${server.pingMs}ms)"),
                                    duration: const Duration(milliseconds: 1200),
                                    backgroundColor: AppTheme.cardSurface,
                                  ),
                                );
                              },
                            );
                          },
                        ),
                      ),
          ),
        ],
      ),
    );
  }
}

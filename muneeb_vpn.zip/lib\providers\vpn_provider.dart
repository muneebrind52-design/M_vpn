import 'dart:async';
import 'dart:math';
import 'package:flutter/foundation.dart';
import '../models/server_model.dart';

enum VpnState { disconnected, connecting, connected, disconnecting, error }

class VpnProvider extends ChangeNotifier {
  VpnState _vpnState = VpnState.disconnected;
  late ServerModel _selectedServer;
  List<ServerModel> _servers = [];

  // Connection metrics
  Timer? _connectionTimer;
  Timer? _speedTicker;
  Duration _connectedDuration = Duration.zero;
  double _downloadSpeed = 0.0;
  double _uploadSpeed = 0.0;

  // Settings
  String _protocol = 'WireGuard (Fastest)';
  bool _killSwitchEnabled = true;
  bool _autoConnectOnLaunch = false;
  String? _errorMessage;

  VpnProvider() {
    _servers = List.from(ServerModel.defaultServers);
    // Default to the optimal server or first server
    _selectedServer = _servers.firstWhere((s) => s.isOptimal, stroke: () => _servers[0]);
  }

  // Getters
  VpnState get vpnState => _vpnState;
  bool get isConnected => _vpnState == VpnState.connected;
  bool get isConnecting => _vpnState == VpnState.connecting;
  bool get isDisconnected => _vpnState == VpnState.disconnected;
  
  ServerModel get selectedServer => _selectedServer;
  List<ServerModel> get servers => UnmodifiableListView(_servers);
  
  Duration get connectedDuration => _connectedDuration;
  double get downloadSpeed => _downloadSpeed;
  double get uploadSpeed => _uploadSpeed;
  
  String get protocol => _protocol;
  bool get killSwitchEnabled => _killSwitchEnabled;
  bool get autoConnectOnLaunch => _autoConnectOnLaunch;
  String? get errorMessage => _errorMessage;

  // Helper extension for firstWhere fallback
  static T _firstWhereFallback<T>(List<T> list, bool Function(T) test, {required T Function() stroke}) {
    for (var element in list) {
      if (test(element)) return element;
    }
    return stroke();
  }

  // Formatting helpers
  String get formattedDuration {
    final hours = _connectedDuration.inHours.toString().padLeft(2, '0');
    final minutes = (_connectedDuration.inMinutes % 60).toString().padLeft(2, '0');
    final seconds = (_connectedDuration.inSeconds % 60).toString().padLeft(2, '0');
    return '$hours:$minutes:$seconds';
  }

  // Toggle connection logic
  Future<void> toggleConnection() async {
    if (_vpnState == VpnState.connected) {
      await disconnect();
    } else if (_vpnState == VpnState.disconnected || _vpnState == VpnState.error) {
      await connect();
    }
  }

  // Connect sequence with realistic simulation phase & potential error handling
  Future<void> connect() async {
    if (_vpnState == VpnState.connecting || _vpnState == VpnState.connected) return;

    _vpnState = VpnState.connecting;
    _errorMessage = null;
    notifyListeners();

    // Simulated network handshake delay
    await Future.delayed(const Duration(seconds: 2));

    // Simulated 5% chance of connection error to demonstrate error handling
    final random = Random();
    if (random.nextInt(100) < 3) {
      _vpnState = VpnState.error;
      _errorMessage = "Handshake timeout on ${_selectedServer.country} gateway. Retrying...";
      notifyListeners();
      return;
    }

    _vpnState = VpnState.connected;
    _connectedDuration = Duration.zero;
    _startDurationTimer();
    _startSpeedSimulation();
    notifyListeners();
  }

  // Disconnect sequence
  Future<void> disconnect() async {
    if (_vpnState == VpnState.disconnecting || _vpnState == VpnState.disconnected) return;

    _vpnState = VpnState.disconnecting;
    notifyListeners();

    await Future.delayed(const Duration(milliseconds: 1200));

    _vpnState = VpnState.disconnected;
    _stopDurationTimer();
    _stopSpeedSimulation();
    notifyListeners();
  }

  // Select server
  Future<void> selectServer(ServerModel server) async {
    if (_selectedServer.id == server.id) return;
    
    final wasConnected = isConnected;
    if (wasConnected) {
      await disconnect();
    }

    _selectedServer = server;
    notifyListeners();

    if (wasConnected) {
      await connect();
    }
  }

  // Auto-Select Optimal Server
  Future<void> autoSelectOptimalServer() async {
    // Find server with lowest ping
    ServerModel optimal = _servers.reduce((a, b) => a.pingMs < b.pingMs ? a : b);
    await selectServer(optimal);
  }

  // Settings handlers
  void setProtocol(String newProtocol) {
    _protocol = newProtocol;
    notifyListeners();
  }

  void toggleKillSwitch(bool value) {
    _killSwitchEnabled = value;
    notifyListeners();
  }

  void toggleAutoConnect(bool value) {
    _autoConnectOnLaunch = value;
    notifyListeners();
  }

  // Duration Timer
  void _startDurationTimer() {
    _connectionTimer?.cancel();
    _connectionTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      _connectedDuration += const Duration(seconds: 1);
      notifyListeners();
    });
  }

  void _stopDurationTimer() {
    _connectionTimer?.cancel();
    _connectedDuration = Duration.zero;
  }

  // Speed Simulation Ticker
  void _startSpeedSimulation() {
    _speedTicker?.cancel();
    final random = Random();
    
    // Set base speed based on ping (lower ping = higher speed)
    final baseSpeed = max(10.0, 100.0 - (_selectedServer.pingMs * 0.5));

    _speedTicker = Timer.periodic(const Duration(seconds: 2), (timer) {
      if (_vpnState != VpnState.connected) return;

      // Add slight jitter
      _downloadSpeed = double.parse((baseSpeed + (random.nextDouble() * 15.0 - 7.5)).toStringAsFixed(1));
      _uploadSpeed = double.parse((baseSpeed * 0.4 + (random.nextDouble() * 6.0 - 3.0)).toStringAsFixed(1));
      
      if (_downloadSpeed < 1.0) _downloadSpeed = 4.2;
      if (_uploadSpeed < 0.5) _uploadSpeed = 1.8;

      notifyListeners();
    });
  }

  void _stopSpeedSimulation() {
    _speedTicker?.cancel();
    _downloadSpeed = 0.0;
    _uploadSpeed = 0.0;
  }

  @override
  void dispose() {
    _connectionTimer?.cancel();
    _speedTicker?.cancel();
    super.dispose();
  }
}

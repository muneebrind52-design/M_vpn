import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/vpn_provider.dart';
import '../theme/app_theme.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  void _showDownloadApkDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) {
        double progress = 0.0;
        return StatefulBuilder(
          builder: (context, setState) {
            // Simulate APK download progress
            if (progress < 1.0) {
              Future.delayed(const Duration(milliseconds: 250), () {
                if (context.mounted && progress < 1.0) {
                  setState(() {
                    progress += 0.15;
                    if (progress > 1.0) progress = 1.0;
                  });
                }
              });
            }

            return AlertDialog(
              backgroundColor: AppTheme.bgSurface,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
                side: const BorderSide(color: AppTheme.primaryNeon, width: 1.5),
              ),
              title: Row(
                children: const [
                  Icon(Icons.android_rounded, color: AppTheme.primaryNeon, size: 28),
                  SizedBox(width: 10),
                  Text(
                    "Download VPN APK",
                    style: TextStyle(color: AppTheme.textWhite, fontSize: 18),
                  ),
                ],
              ),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    progress < 1.0
                        ? "Downloading latest release package (muneeb_vpn_v1.0.0.apk)..."
                        : "APK download completed successfully!",
                    style: const TextStyle(color: AppTheme.textMuted, fontSize: 13),
                  ),
                  const SizedBox(height: 20),
                  LinearProgressIndicator(
                    value: progress,
                    backgroundColor: Colors.white10,
                    valueColor: const AlwaysStoppedAnimation<Color>(AppTheme.primaryNeon),
                    borderRadius: BorderRadius.circular(8),
                    minHeight: 8,
                  ),
                  const SizedBox(height: 8),
                  Align(
                    alignment: Alignment.centerRight,
                    child: Text(
                      '${(progress * 100).toInt()}%',
                      style: const TextStyle(color: AppTheme.primaryNeon, fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
              actions: [
                if (progress >= 1.0) ...[
                  TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text("CLOSE", style: TextStyle(color: AppTheme.textMuted)),
                  ),
                  ElevatedButton.icon(
                    onPressed: () {
                      Navigator.pop(context);
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text("APK saved to Downloads folder (muneeb_vpn_release.apk)"),
                          backgroundColor: AppTheme.connectedGreen,
                        ),
                      );
                    },
                    icon: const Icon(Icons.install_mobile_rounded, size: 18),
                    label: const Text("INSTALL APK"),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppTheme.primaryNeon,
                      foregroundColor: Colors.black,
                    ),
                  ),
                ] else ...[
                  TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text("CANCEL", style: TextStyle(color: AppTheme.textDim)),
                  ),
                ],
              ],
            );
          },
        );
      },
    );
  }

  void _showProtocolSelector(BuildContext context, VpnProvider provider) {
    final protocols = [
      'WireGuard (Fastest)',
      'OpenVPN (UDP)',
      'OpenVPN (TCP)',
      'IKEv2 (Mobile Optimized)',
    ];

    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.bgSurface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "Select VPN Protocol",
                style: TextStyle(
                  color: AppTheme.textWhite,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              ...protocols.map((protocol) {
                final isSelected = provider.protocol == protocol;
                return ListTile(
                  title: Text(
                    protocol,
                    style: TextStyle(
                      color: isSelected ? AppTheme.primaryNeon : AppTheme.textWhite,
                      fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                    ),
                  ),
                  trailing: isSelected
                      ? const Icon(Icons.check_circle_rounded, color: AppTheme.primaryNeon)
                      : null,
                  onTap: () {
                    provider.setProtocol(protocol);
                    Navigator.pop(context);
                  },
                );
              }),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final vpnProvider = Provider.of<VpnProvider>(context);

    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        title: const Text("App Settings"),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Developer Credit Card (App by Muneeb)
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: AppTheme.cardGradient,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: AppTheme.primaryNeon.withOpacity(0.4), width: 1.2),
              boxShadow: AppTheme.neonGlow(color: AppTheme.secondaryNeon, opacity: 0.25, blur: 15),
            ),
            child: Row(
              children: [
                Container(
                  width: 56,
                  height: 56,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: AppTheme.neonGradient,
                  ),
                  child: const Center(
                    child: Icon(Icons.person_rounded, color: Colors.white, size: 32),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      Text(
                        "MUNEEB VPN PRO",
                        style: TextStyle(
                          color: AppTheme.textWhite,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 0.5,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        "App by Muneeb",
                        style: TextStyle(
                          color: AppTheme.primaryNeon,
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      SizedBox(height: 2),
                      Text(
                        "Made with ❤️ by Muneeb",
                        style: TextStyle(
                          color: AppTheme.textMuted,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: AppTheme.primaryNeon.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: AppTheme.primaryNeon, width: 0.8),
                  ),
                  child: const Text(
                    "v1.0.0",
                    style: TextStyle(
                      color: AppTheme.primaryNeon,
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 24),

          // Download APK Feature Button
          GestureDetector(
            onTap: () => _showDownloadApkDialog(context),
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppTheme.cardSurface,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: AppTheme.primaryNeon.withOpacity(0.6), width: 1.5),
                boxShadow: AppTheme.neonGlow(color: AppTheme.primaryNeon, opacity: 0.2, blur: 10),
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: AppTheme.primaryNeon.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(Icons.android_rounded, color: AppTheme.primaryNeon, size: 24),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: const [
                        Text(
                          "Download Standalone APK",
                          style: TextStyle(
                            color: AppTheme.textWhite,
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 2),
                        Text(
                          "Get release package for manual installation",
                          style: TextStyle(color: AppTheme.textMuted, fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                  const Icon(Icons.file_download_rounded, color: AppTheme.primaryNeon, size: 24),
                ],
              ),
            ),
          ),

          const SizedBox(height: 24),

          const Padding(
            padding: EdgeInsets.only(left: 4, bottom: 8),
            child: Text(
              "VPN CONFIGURATION",
              style: TextStyle(
                color: AppTheme.textMuted,
                fontSize: 11,
                fontWeight: FontWeight.bold,
                letterSpacing: 1.2,
              ),
            ),
          ),

          // Protocol Selector
          _SettingsTile(
            icon: Icons.alt_route_rounded,
            title: "Protocol",
            subtitle: vpnProvider.protocol,
            onTap: () => _showProtocolSelector(context, vpnProvider),
          ),

          // Kill Switch Toggle
          _SettingsSwitchTile(
            icon: Icons.security_rounded,
            title: "Kill Switch",
            subtitle: "Block internet traffic if VPN disconnects unexpectedly",
            value: vpnProvider.killSwitchEnabled,
            onChanged: (val) => vpnProvider.toggleKillSwitch(val),
          ),

          // Auto-Connect Toggle
          _SettingsSwitchTile(
            icon: Icons.autorenew_rounded,
            title: "Auto-Connect on Launch",
            subtitle: "Automatically establish VPN tunnel when app opens",
            value: vpnProvider.autoConnectOnLaunch,
            onChanged: (val) => vpnProvider.toggleAutoConnect(val),
          ),

          const SizedBox(height: 24),

          const Padding(
            padding: EdgeInsets.only(left: 4, bottom: 8),
            child: Text(
              "ABOUT & LEGAL",
              style: TextStyle(
                color: AppTheme.textMuted,
                fontSize: 11,
                fontWeight: FontWeight.bold,
                letterSpacing: 1.2,
              ),
            ),
          ),

          _SettingsTile(
            icon: Icons.privacy_tip_outlined,
            title: "Privacy Policy",
            subtitle: "Zero-log policy guarantees 100% anonymized browsing",
            onTap: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text("Strict No-Logs Policy Active")),
              );
            },
          ),

          _SettingsTile(
            icon: Icons.info_outline_rounded,
            title: "App Credits",
            subtitle: "App by Muneeb • Developed with Flutter",
            onTap: () {},
          ),

          const SizedBox(height: 30),

          // Footer Text
          const Center(
            child: Text(
              "Made with ❤️ by Muneeb\n© 2026 Muneeb VPN. All rights reserved.",
              textAlign: TextAlign.center,
              style: TextStyle(
                color: AppTheme.textDim,
                fontSize: 12,
                height: 1.5,
              ),
            ),
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }
}

class _SettingsTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _SettingsTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: AppTheme.cardSurface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.cardBorder),
      ),
      child: ListTile(
        onTap: onTap,
        leading: Icon(icon, color: AppTheme.primaryNeon),
        title: Text(
          title,
          style: const TextStyle(color: AppTheme.textWhite, fontSize: 15, fontWeight: FontWeight.w600),
        ),
        subtitle: Text(
          subtitle,
          style: const TextStyle(color: AppTheme.textMuted, fontSize: 12),
        ),
        trailing: const Icon(Icons.chevron_right_rounded, color: AppTheme.textDim),
      ),
    );
  }
}

class _SettingsSwitchTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;

  const _SettingsSwitchTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.value,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: AppTheme.cardSurface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.cardBorder),
      ),
      child: SwitchListTile(
        secondary: Icon(icon, color: AppTheme.primaryNeon),
        title: Text(
          title,
          style: const TextStyle(color: AppTheme.textWhite, fontSize: 15, fontWeight: FontWeight.w600),
        ),
        subtitle: Text(
          subtitle,
          style: const TextStyle(color: AppTheme.textMuted, fontSize: 12),
        ),
        value: value,
        onChanged: onChanged,
        activeColor: AppTheme.primaryNeon,
      ),
    );
  }
}

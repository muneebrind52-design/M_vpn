class ServerModel {
  final String id;
  final String country;
  final String flagEmoji;
  final int pingMs;
  final String ipAddress;
  final String location;
  final bool isOptimal;

  const ServerModel({
    required this.id,
    required this.country,
    required this.flagEmoji,
    required this.pingMs,
    required this.ipAddress,
    required this.location,
    this.isOptimal = false,
  });

  // Pre-configured 12 Country Servers as requested
  static final List<ServerModel> defaultServers = [
    const ServerModel(
      id: 'us_01',
      country: 'United States',
      flagEmoji: '🇺🇸',
      pingMs: 34,
      ipAddress: '198.51.100.45',
      location: 'New York, US',
    ),
    const ServerModel(
      id: 'uk_01',
      country: 'United Kingdom',
      flagEmoji: '🇬🇧',
      pingMs: 51,
      ipAddress: '185.220.101.5',
      location: 'London, UK',
    ),
    const ServerModel(
      id: 'de_01',
      country: 'Germany',
      flagEmoji: '🇩🇪',
      pingMs: 68,
      ipAddress: '185.246.188.12',
      location: 'Frankfurt, DE',
    ),
    const ServerModel(
      id: 'fr_01',
      country: 'France',
      flagEmoji: '🇫🇷',
      pingMs: 72,
      ipAddress: '193.56.28.91',
      location: 'Paris, FR',
    ),
    const ServerModel(
      id: 'ca_01',
      country: 'Canada',
      flagEmoji: '🇨🇦',
      pingMs: 45,
      ipAddress: '142.44.210.14',
      location: 'Toronto, CA',
    ),
    const ServerModel(
      id: 'jp_01',
      country: 'Japan',
      flagEmoji: '🇯🇵',
      pingMs: 89,
      ipAddress: '153.127.60.2',
      location: 'Tokyo, JP',
    ),
    const ServerModel(
      id: 'au_01',
      country: 'Australia',
      flagEmoji: '🇦🇺',
      pingMs: 123,
      ipAddress: '139.99.144.23',
      location: 'Sydney, AU',
    ),
    const ServerModel(
      id: 'in_01',
      country: 'India',
      flagEmoji: '🇮🇳',
      pingMs: 18,
      ipAddress: '103.21.124.77',
      location: 'Mumbai, IN',
      isOptimal: true,
    ),
    const ServerModel(
      id: 'sg_01',
      country: 'Singapore',
      flagEmoji: '🇸🇬',
      pingMs: 42,
      ipAddress: '128.199.200.11',
      location: 'Singapore, SG',
    ),
    const ServerModel(
      id: 'br_01',
      country: 'Brazil',
      flagEmoji: '🇧🇷',
      pingMs: 98,
      ipAddress: '177.136.250.88',
      location: 'São Paulo, BR',
    ),
    const ServerModel(
      id: 'nl_01',
      country: 'Netherlands',
      flagEmoji: '🇳🇱',
      pingMs: 55,
      ipAddress: '95.211.205.10',
      location: 'Amsterdam, NL',
    ),
    const ServerModel(
      id: 'kr_01',
      country: 'South Korea',
      flagEmoji: '🇰🇷',
      pingMs: 76,
      ipAddress: '211.233.72.15',
      location: 'Seoul, KR',
    ),
  ];
}

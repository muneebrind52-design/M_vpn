import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../providers/vpn_provider.dart';
import '../theme/app_theme.dart';

class ConnectButton extends StatefulWidget {
  final VpnState state;
  final VoidCallback onTap;

  const ConnectButton({
    super.key,
    required this.state,
    required this.onTap,
  });

  @override
  State<ConnectButton> createState() => _ConnectButtonState();
}

class _ConnectButtonState extends State<ConnectButton> with SingleTickerProviderStateMixin {
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;
  late Animation<double> _rotationAnimation;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    );

    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.22).animate(
      CurvedAnimation(
        parent: _pulseController,
        curve: Curves.easeInOut,
      ),
    );

    _rotationAnimation = Tween<double>(begin: 0.0, end: 2 * math.pi).animate(
      CurvedAnimation(
        parent: _pulseController,
        curve: Curves.linear,
      ),
    );

    _updateAnimationState();
  }

  @override
  void didUpdateWidget(ConnectButton oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.state != widget.state) {
      _updateAnimationState();
    }
  }

  void _updateAnimationState() {
    if (widget.state == VpnState.connecting || widget.state == VpnState.disconnecting) {
      _pulseController.repeat(reverse: true);
    } else if (widget.state == VpnState.connected) {
      _pulseController.repeat(reverse: true);
    } else {
      _pulseController.stop();
      _pulseController.reset();
    }
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  Color get _buttonPrimaryColor {
    switch (widget.state) {
      case VpnState.connected:
        return AppTheme.connectedGreen;
      case VpnState.connecting:
      case VpnState.disconnecting:
        return AppTheme.connectingYellow;
      case VpnState.error:
        return AppTheme.disconnectedRed;
      case VpnState.disconnected:
      default:
        return AppTheme.primaryNeon;
    }
  }

  String get _buttonText {
    switch (widget.state) {
      case VpnState.connected:
        return "DISCONNECT";
      case VpnState.connecting:
        return "CONNECTING...";
      case VpnState.disconnecting:
        return "STOPPING...";
      case VpnState.error:
        return "RETRY";
      case VpnState.disconnected:
      default:
        return "TAP TO CONNECT";
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (context, child) {
        final glowScale = (widget.state == VpnState.connecting || widget.state == VpnState.connected)
            ? _pulseAnimation.value
            : 1.0;

        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            GestureDetector(
              onTap: widget.onTap,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  // Outer Glow Pulse Ring 2
                  Transform.scale(
                    scale: glowScale * 1.15,
                    child: Container(
                      width: 190,
                      height: 190,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _buttonPrimaryColor.withOpacity(0.08),
                      ),
                    ),
                  ),
                  // Outer Glow Pulse Ring 1
                  Transform.scale(
                    scale: glowScale,
                    child: Container(
                      width: 165,
                      height: 165,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _buttonPrimaryColor.withOpacity(0.18),
                        boxShadow: AppTheme.neonGlow(
                          color: _buttonPrimaryColor,
                          opacity: 0.35,
                          blur: 30,
                        ),
                      ),
                    ),
                  ),
                  // 3D Glass Outer Ring
                  Container(
                    width: 140,
                    height: 140,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: [
                          _buttonPrimaryColor,
                          widget.state == VpnState.connected
                              ? const Color(0xFF00B0FF)
                              : AppTheme.secondaryNeon,
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: _buttonPrimaryColor.withOpacity(0.5),
                          blurRadius: 25,
                          spreadRadius: 3,
                          offset: const Offset(0, 8),
                        ),
                        BoxShadow(
                          color: Colors.black.withOpacity(0.6),
                          blurRadius: 15,
                          spreadRadius: -2,
                          offset: const Offset(0, 10),
                        ),
                      ],
                    ),
                  ),
                  // Inner 3D Convex Button Cap
                  Container(
                    width: 124,
                    height: 124,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: [
                          const Color(0xFF1E283C),
                          const Color(0xFF121724),
                        ],
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                      ),
                      border: Border.all(
                        color: Colors.white.withOpacity(0.2),
                        width: 1.5,
                      ),
                    ),
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            widget.state == VpnState.connected
                                ? Icons.power_settings_new_rounded
                                : (widget.state == VpnState.connecting
                                    ? Icons.sync_rounded
                                    : Icons.power_settings_new_rounded),
                            size: 48,
                            color: _buttonPrimaryColor,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            // Button Label Subtext
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 300),
              child: Text(
                _buttonText,
                key: ValueKey(_buttonText),
                style: TextStyle(
                  color: _buttonPrimaryColor,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2.0,
                  shadows: [
                    Shadow(
                      color: _buttonPrimaryColor.withOpacity(0.5),
                      blurRadius: 10,
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

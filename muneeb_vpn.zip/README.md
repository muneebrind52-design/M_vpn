# 🛡️ Muneeb VPN - Fast & Secure VPN App in Flutter

A modern, ultra-fast VPN application built using Flutter and Provider state management. Styled with a dark aesthetic, neon blue (`#00D4FF`) and purple (`#7B2FBE`) gradient accents, a 3D glowing pulse connect button, a 12-country server list with ping latency metrics, and developer credits.

---

## ✨ Features

- **⚡ 1-Tap Connect/Disconnect**: Central glowing 3D button with dynamic pulsing radial animations during connection handshakes.
- **🌍 12 Country Servers with Live Mock Ping**:
  - 🇺🇸 US Server (34ms)
  - 🇬🇧 UK Server (51ms)
  - 🇩🇪 Germany (68ms)
  - 🇫🇷 France (72ms)
  - 🇨🇦 Canada (45ms)
  - 🇯🇵 Japan (89ms)
  - 🇦🇺 Australia (123ms)
  - 🇮🇳 India (18ms - *Optimal*)
  - 🇸GRect Singapore (42ms)
  - 🇧🇷 Brazil (98ms)
  - 🇳🇱 Netherlands (55ms)
  - 🇰🇷 South Korea (76ms)
- **🔍 Server Search & Auto-Select**: Filter servers by country name or location, with a single-tap "Auto-Select Optimal Server" button.
- **📊 Real-time Speed & Duration Meter**: Live download/upload speed ticker and connection duration counter.
- **⚙️ Settings & APK Download**: Includes VPN protocol switcher (WireGuard, OpenVPN, IKEv2), Kill Switch toggle, App Info, and an in-app **Download APK** dialog.
- **👨‍💻 Developer Credits**:
  - **App by Muneeb**
  - **Made with ❤️ by Muneeb**

---

## 🎨 Design System

- **Dark Background**: `#0B0E17` / `#131A29`
- **Neon Cyan Accent**: `#00D4FF`
- **Neon Purple Accent**: `#7B2FBE`
- **Connected Green**: `#00E676`
- **Cards & Glassmorphism**: Rounded borders with neon glow shadows.

---

## 📱 Project Architecture

```
muneeb_vpn/
├── android/                   # Android native gradle config & permissions
├── assets/images/vpn_logo.jpg  # Generated high-resolution VPN logo
├── build_apk.ps1              # Automation build script for APK release
├── pubspec.yaml               # Dependencies (provider, cupertino_icons, etc.)
└── lib/
    ├── main.dart              # App entry point & theme initialization
    ├── models/
    │   └── server_model.dart  # 12 Country server definitions & ping data
    ├── providers/
    │   └── vpn_provider.dart  # ChangeNotifier state machine (5 VPN states, timers, speed ticker)
    ├── theme/
    │   └── app_theme.dart     # Neon color tokens, gradients, and dark theme
    ├── widgets/
    │   ├── connect_button.dart# 3D glowing pulse connect button
    │   ├── server_card.dart   # Server card with ping badge & selection highlight
    │   ├── status_badge.dart  # Animated status badge with pulsing dots
    │   └── speed_widget.dart  # Network speed meter (Download/Upload)
    └── screens/
        ├── splash_screen.dart # Animated logo splash transition
        ├── main_scaffold.dart # Custom bottom navigation container
        ├── home_screen.dart   # Main dashboard with button, status & stats
        ├── server_list_screen.dart # 12 country list view with search filter
        └── settings_screen.dart    # Credits, APK download & protocol toggles
```

---

## 🚀 Quick Setup & How to Run

### 1. Prerequisites
- [Flutter SDK](https://docs.flutter.dev/get-started/install) installed and added to PATH.
- Android Studio / VS Code configured with Android SDK.

### 2. Run in Debug Mode
Open terminal inside project directory (`C:\Users\ITX ME\.gemini\antigravity\scratch\muneeb_vpn`):
```bash
# Get dependencies
flutter pub get

# Run on connected device or emulator
flutter run
```

---

## 📦 How to Build the Release APK

### Option A: Using the PowerShell Script
Execute the included automated build script in PowerShell:
```powershell
.\build_apk.ps1
```

### Option B: Using Manual Command
Run the standard Flutter build command:
```bash
flutter build apk --release
```
The output APK file will be generated at:
`build/app/outputs/flutter-apk/app-release.apk`

---

## 🔑 Generate Signed Release APK

To sign the APK with your own keystore:

1. **Generate a keystore**:
   ```bash
   keytool -genkey -v -keystore android/app/upload-keystore.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload
   ```

2. **Create `android/key.properties`**:
   ```properties
   storePassword=<your-store-password>
   keyPassword=<your-key-password>
   keyAlias=upload
   storeFile=upload-keystore.jks
   ```

3. **Rebuild Release APK**:
   ```bash
   flutter build apk --release
   ```

---
*App by Muneeb • Made with ❤️ by Muneeb*
